# Sistema de Projetos Acadêmicos — Modelagem UML

Entrega da questão 1 da **Avaliação NP1 / Prova Prática** de Análise e Projeto Orientado a Objetos.

| Identificação | Dados |
| --- | --- |
| Acadêmico | Victor Gabriel Pereira da Silva |
| Instituição | Centro Universitário de Ciências e Tecnologia do Maranhão — UniFacema |
| Curso | Análise e Desenvolvimento de Sistemas |
| Período e turno | 3º período — Noturno |
| Unidade curricular | Análise e Projeto Orientado a Objetos |
| Professor | Marcos Gomes da Silva Rocha |
| Campus | Caxias |

## Objetivo

Representar um sistema que permite submeter propostas de projetos, registrar relatórios de progresso com descrição, data de envio e anexos, encaminhá-los ao orientador e acompanhar sua avaliação. A aprovação valida o relatório e atualiza o histórico acadêmico. A solicitação de correções devolve o relatório ao estudante, que pode corrigi-lo e reenviá-lo. A coordenação acompanha projetos, consulta relatórios e visualiza estatísticas de participação.

## Arquivos da entrega

| Arquivo | Finalidade |
| --- | --- |
| [Modelagem_UML_Projetos_Academicos.pdf](documentacao/Modelagem_UML_Projetos_Academicos.pdf) | Documento com os três diagramas; pronto para consultar ou entregar. |
| [Modelagem_Projetos_Academicos.drawio](diagramas/Modelagem_Projetos_Academicos.drawio) | Arquivo editável, com uma aba para cada diagrama. |
| `diagramas/*.png` | Imagens dos diagramas exibidas neste README. |
| `diagramas/*.svg` | Versões vetoriais dos diagramas, ampliáveis sem perda de qualidade. |
| [Decisoes_de_Modelagem.md](documentacao/Decisoes_de_Modelagem.md) | Premissas, relações entre classes e regras de negócio. |

## a) Diagrama de Casos de Uso

Os atores são **Estudante**, **Professor Orientador** e **Coordenação**. As relações `«include»` representam comportamentos obrigatórios: encaminhar o relatório após o envio ou reenvio, atualizar o histórico após a aprovação e retornar o relatório quando forem solicitadas correções.

![Diagrama de Casos de Uso](diagramas/01-casos-de-uso.png)

## b) Diagrama de Classes

O modelo apresenta atributos, operações, associações, composições, dependências e multiplicidades. Os relatórios pertencem a projetos e podem conter anexos e comentários. O histórico registra somente os relatórios validados.

![Diagrama de Classes](diagramas/02-classes.png)

## c) Diagrama de Atividades

As raias separam as ações do estudante, do sistema e do orientador. O fluxo contempla envio inicial, registro dos dados, encaminhamento automático, análise, comentários opcionais, decisão de aprovação, atualização do histórico e o ciclo de correção e reenvio. Toda nova submissão passa novamente pelo registro dos dados e pela análise do orientador.

![Diagrama de Atividades](diagramas/03-atividades.png)

## Como abrir o arquivo editável

1. Acesse [diagrams.net / draw.io](https://app.diagrams.net/).
2. Se solicitado, escolha **Dispositivo** como local de armazenamento.
3. Use **Arquivo → Abrir de → Dispositivo** e selecione `Modelagem_Projetos_Academicos.drawio`.
4. Use as abas inferiores para alternar entre os três diagramas.
5. Após editar, salve o arquivo pelo menu **Arquivo**.

## Como subir a entrega no GitHub

1. Extraia o arquivo ZIP recebido.
2. No GitHub, crie um repositório, por exemplo, `projetos-academicos-uml`.
3. No repositório, escolha **Add file → Upload files**.
4. Envie o **conteúdo** da pasta `projetos-academicos-uml`: `README.md` e as pastas `diagramas` e `documentacao`. Mantenha essas pastas para que as imagens e os links funcionem.
5. Clique em **Commit changes**.
6. Confira se os três diagramas aparecem no README e se o PDF abre.
7. Copie o link do repositório e envie ao professor conforme o enunciado. Para repositório privado, conceda acesso ao professor antes do envio.

**Título indicado para a entrega:**

`Prova Prática + Análise e Projeto Orientado a Objetos + Victor Gabriel Pereira da Silva + 3º período`

Esta entrega contém a modelagem UML solicitada no enunciado.
