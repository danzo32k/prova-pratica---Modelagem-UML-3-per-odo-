# Decisões de modelagem

## Escopo e premissas

O modelo cobre propostas de projetos, relatórios periódicos, avaliação do orientador e acompanhamento pela coordenação. As ações automáticas são responsabilidades do sistema e aparecem explicitamente no diagrama de atividades.

Para definir as multiplicidades, considera-se um estudante responsável e um professor orientador por projeto. O enunciado não descreve projetos em grupo nem coorientação. Um projeto pode ainda não ter relatórios. Anexos e comentários podem estar ausentes; por isso, suas multiplicidades são `0..*`.

A classe `Projeto` representa a proposta cadastrada e o projeto acompanhado. Não foi criada uma classe de proposta separada, pois o enunciado não especifica um processo independente de avaliação de propostas.

## Classes e responsabilidades

| Classe | Responsabilidade |
| --- | --- |
| Estudante | Submeter propostas e enviar ou reenviar relatórios. |
| ProfessorOrientador | Orientar projetos, analisar relatórios, registrar comentários, aprovar e solicitar correções. |
| Coordenacao | Representar o papel administrativo que acompanha projetos, consulta relatórios e visualiza estatísticas. |
| Projeto | Guardar os dados do projeto e reunir seus relatórios. |
| Relatorio | Guardar descrição das atividades, data de envio e status; reunir anexos e comentários. |
| Anexo | Identificar um arquivo vinculado a um relatório. |
| Comentario | Guardar o texto e a data do comentário do professor. |
| HistoricoAcademico | Registrar os relatórios validados do estudante. |

`StatusRelatorio` é um tipo enumerado, indicado na nota do diagrama, com os valores `EM_ANALISE`, `CORRECAO_SOLICITADA` e `VALIDADO`. Os atributos usam `-` para visibilidade privada e as operações usam `+` para visibilidade pública.

## Relacionamentos e multiplicidades

| Relacionamento | Interpretação |
| --- | --- |
| Estudante `1` — Projeto `0..*` | Cada projeto tem um estudante responsável; um estudante pode submeter vários projetos. |
| ProfessorOrientador `1` — Projeto `0..*` | Cada projeto tem um orientador; um professor pode orientar vários projetos. |
| Projeto `1` ◆— Relatorio `0..*` | Cada relatório pertence a um projeto; um projeto pode ter vários relatórios. |
| Relatorio `1` ◆— Anexo `0..*` | Cada anexo pertence a um relatório; um relatório pode ter vários anexos. |
| Relatorio `1` ◆— Comentario `0..*` | Cada comentário pertence a um relatório; um relatório pode receber vários comentários. |
| ProfessorOrientador `1` — Comentario `0..*` | Cada comentário tem um professor autor; um professor pode registrar vários comentários. |
| Estudante `1` ◆— HistoricoAcademico `1` | Cada estudante tem um histórico próprio. |
| Relatorio `0..*` — HistoricoAcademico `0..1` | Um histórico pode registrar vários relatórios; um relatório ainda não validado não integra o histórico. Após validado, integra o histórico de seu estudante responsável. |
| Coordenacao `«use»` Projeto / Relatorio | Dependências de consulta e acompanhamento; não representam propriedade dessas entidades. |

O losango preenchido indica composição e fica no lado da entidade que contém as partes. Não representa uma política de exclusão de registros do banco de dados. As multiplicidades estão junto às extremidades correspondentes.

## Regras de negócio

1. O envio registra descrição, data e anexos e coloca o relatório em `EM_ANALISE`.
2. O sistema encaminha o relatório ao orientador do projeto, tanto no envio inicial quanto no reenvio.
3. O professor pode registrar comentários durante a análise.
4. A aprovação altera o status para `VALIDADO` e registra o relatório no histórico do estudante responsável pelo projeto.
5. A solicitação de correções altera o status para `CORRECAO_SOLICITADA` e devolve o relatório ao estudante.
6. Após corrigir e reenviar, o relatório retorna a `EM_ANALISE` e percorre novamente o processo de avaliação.
7. Somente relatórios `VALIDADO` podem integrar o histórico. O estudante desse histórico deve ser o mesmo responsável pelo projeto do relatório.
8. O autor de um comentário de avaliação deve ser o orientador responsável pelo projeto.
9. A coordenação consulta dados de acompanhamento e estatísticas; não participa da decisão de aprovação do relatório.

## Notação dos demais diagramas

Nos casos de uso, os atores ficam fora do limite do sistema e as associações são linhas contínuas. A seta tracejada `«include»` aponta do caso principal para o comportamento incluído, que ocorre obrigatoriamente.

Nas atividades, o círculo preenchido é o início e o círculo com borda dupla é o fim. As decisões possuem condições `[sim]` e `[não]`. Os losangos sem texto unem caminhos alternativos; eles não representam execução paralela. As raias indicam quem executa cada ação.
